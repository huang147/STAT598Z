import numpy as np
import matplotlib.pyplot as plt

# define 3 functions 
def fx(x):
    return np.sin(x)

def gx(x):
    return np.cos(x)

def hx(x):
    return np.tan(x)

# limit x on interval [-10,10]
x = np.linspace(-10,10,num = 10000)

# get the y on different functions
yf = []
yg = []
yh = []

for v in x:
    yf.append(fx(v))
    yg.append(gx(v))
    yh.append(hx(v))


# make the plots for f(x), g(x), and h(x)
# set figure size and resolution
fig = plt.figure(1,figsize = (15,10),dpi=100)
# the first subplot: f(x) vs x
pyf = fig.add_subplot(1,3,1)
# make the plot, specify line color and width
pyf.plot(x,yf,'b',linewidth=2)
# set the position of subplot so it won't overlap with other subplots
pyf.set_position([0.10,0.15,0.20,0.30])
# plot the grid
plt.grid(True)
# limit y value on interval [-1,1]
plt.ylim(-1,1)
# plot title and x, y labels
plt.title(r"$sin wave$")
plt.xlabel(r"$x$")
plt.ylabel(r"$sin(x)$")


pyg = fig.add_subplot(1,3,2)
pyg.plot(x,yg,'b',linewidth=2)
pyg.set_position([0.40,0.15,0.20,0.30])
plt.grid(True)
plt.ylim(-1,1)
plt.title(r"$cos wave$")
plt.xlabel(r"$x$")
plt.ylabel(r"$cos(x)$")


pyh = fig.add_subplot(1,3,3)
pyh.plot(x,yh,'b',linewidth=2)
pyh.set_position([0.70,0.15,0.20,0.30])
plt.grid(True)
# set the limit of y to be [-1,1]
# please note that y here has a lot more value points outside this limit
plt.ylim(-1,1)
plt.title(r"$tan wave$")
plt.xlabel(r"$x$")
plt.ylabel(r"$tan(x)$")


# save figure and show it on screen
fig.savefig('triangular.png')
plt.show()



